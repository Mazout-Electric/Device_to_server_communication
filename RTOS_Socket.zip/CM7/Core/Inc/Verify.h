/*
 * Verify.h
 *
 *  Created on: Dec 13, 2024
 *      Author: pirda
 */

#ifndef INC_VERIFY_H_
#define INC_VERIFY_H_

#include "SimCom.h"

char verify(const char *data, SIMCOM_LENGTH_TYPE length);

#endif /* INC_VERIFY_H_ */
